export interface ContactData {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  status: string;
}
